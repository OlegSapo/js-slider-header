class Test {
  test = 'Test'
}

module.exports = Test
